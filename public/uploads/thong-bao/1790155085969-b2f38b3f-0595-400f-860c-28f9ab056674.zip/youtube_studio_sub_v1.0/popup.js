document.getElementById('open').addEventListener('click', async () => {
  const status = document.getElementById('status');
  try {
    const window = await chrome.windows.getCurrent();
    await chrome.sidePanel.open({ windowId: window.id });
    globalThis.close();
  } catch (error) { status.textContent = error.message; }
});