chrome.runtime.onInstalled.addListener(() => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }));
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message.type === 'open-panel') {
    chrome.sidePanel.open({ windowId: sender.tab?.windowId || message.windowId })
      .then(() => reply({ ok: true }), error => reply({ ok: false, error: error.message }));
    return true;
  }
});