(() => {
  const $ = id => document.getElementById(id);
  const languagesEl = $('languages');
  const resultsEl = $('results');
  const progressEl = $('progress');
  const resultRows = new Map();

  let tabId = null;
  let videoId = null;
  let languages = [];
  let selectedFile = null;
  let port = null;
  let running = false;

  const status = message => {
    if (progressEl.textContent !== message) progressEl.textContent = message;
  };

  function updateStart() {
    $('start').disabled = running || !selectedFile || !videoId || !languagesEl.querySelector('input:checked');
  }

  function renderLanguages() {
    languagesEl.replaceChildren();
    const fragment = document.createDocumentFragment();
    for (const item of languages) {
      const label = document.createElement('label');
      label.className = 'language';
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.value = item.name;
      box.checked = !item.existing;
      box.disabled = item.existing;
      box.addEventListener('change', updateStart);
      const text = document.createElement('span');
      text.textContent = item.name;
      label.append(box, text);
      if (item.existing) {
        const small = document.createElement('small');
        small.textContent = 'Đã có';
        label.append(small);
      }
      fragment.append(label);
    }
    languagesEl.append(fragment);
    updateStart();
  }

  async function activeTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0];
  }

  async function refresh() {
    $('pageStatus').textContent = 'Đang đọc trang Studio…';
    try {
      const tab = await activeTab();
      tabId = tab?.id;
      if (!tab?.url?.startsWith('https://studio.youtube.com/video/')) throw Error('Mở trang Ngôn ngữ của một video trong YouTube Studio.');
      const response = await chrome.tabs.sendMessage(tabId, { type: 'discover' });
      if (!response.ok) throw Error(response.error);
      videoId = response.videoId;
      languages = response.languages;
      $('pageStatus').textContent = `${languages.length} ngôn ngữ khả dụng · Video ${videoId}`;
      renderLanguages();
    } catch (error) {
      videoId = null;
      languages = [];
      renderLanguages();
      $('pageStatus').textContent = error.message || 'Không kết nối được với Studio. Hãy tải lại trang.';
    }
  }

  $('file').addEventListener('change', event => {
    const file = event.target.files?.[0];
    if (!file || !/\.mp3$/i.test(file.name) || file.size < 1 || (file.type && file.type !== 'audio/mpeg' && file.type !== 'audio/mp3')) {
      selectedFile = null;
      $('fileInfo').textContent = 'Hãy chọn một tệp MP3 không rỗng.';
    } else {
      selectedFile = file;
      $('fileInfo').textContent = `${file.name} · ${(file.size / 1048576).toFixed(1)} MB`;
    }
    updateStart();
  });

  $('refresh').addEventListener('click', refresh);
  $('stop').addEventListener('click', () => {
    port?.postMessage({ type: 'stop' });
    status('Đang dừng sau bước hiện tại…');
  });

  function bytesToBinary(bytes) {
    // PERF: avoid one string concatenation per byte while preserving the same
    // base64 transport protocol and chunk size.
    const parts = [];
    const block = 0x8000;
    for (let i = 0; i < bytes.length; i += block) {
      parts.push(String.fromCharCode(...bytes.subarray(i, i + block)));
    }
    return parts.join('');
  }

  async function sendFile(activePort, file) {
    let waiter;
    const responses = [];
    const listener = message => {
      if (waiter) {
        const resolve = waiter;
        waiter = null;
        resolve(message);
      } else {
        responses.push(message);
      }
    };
    activePort.onMessage.addListener(listener);

    const next = () => new Promise((resolve, reject) => {
      if (responses.length) return resolve(responses.shift());
      const timer = setTimeout(() => {
        waiter = null;
        reject(Error('Quá thời gian truyền MP3.'));
      }, 15000);
      waiter = message => {
        clearTimeout(timer);
        resolve(message);
      };
    });

    try {
      activePort.postMessage({ type: 'begin', name: file.name, size: file.size });
      let reply = await next();
      if (reply.type !== 'ready') throw Error(reply.error || 'Không thể bắt đầu truyền MP3.');

      const size = 48 * 1024;
      for (let offset = 0, index = 0; offset < file.size; offset += size, index++) {
        const bytes = new Uint8Array(await file.slice(offset, offset + size).arrayBuffer());
        activePort.postMessage({ type: 'chunk', index, data: btoa(bytesToBinary(bytes)) });
        reply = await next();
        if (reply.type !== 'ack' || reply.index !== index) throw Error(reply.error || 'Thứ tự dữ liệu MP3 không hợp lệ.');
        status(`Đang truyền MP3: ${Math.min(100, Math.round((offset + bytes.length) / file.size * 100))}%`);
      }

      activePort.postMessage({ type: 'end' });
      reply = await next();
      if (reply.type !== 'file-ready') throw Error(reply.error || 'MP3 chưa truyền xong.');
    } finally {
      activePort.onMessage.removeListener(listener);
      responses.length = 0;
      waiter = null;
    }
  }

  function appendResult(message) {
    let row = resultRows.get(message.name);
    if (!row) {
      row = document.createElement('div');
      row.className = 'result';
      row.dataset.language = message.name;
      resultRows.set(message.name, row);
      resultsEl.append(row);
    }
    row.className = `result ${message.status}`;
    row.textContent = `${message.name}: ${message.status === 'success' ? 'Thành công' : message.status === 'failed' ? `Lỗi — ${message.error}` : message.status === 'skipped' ? 'Bỏ qua' : 'Đang xử lý'}`;
  }

  function closePort() {
    if (!port) return;
    const activePort = port;
    port = null;
    try { activePort.disconnect(); } catch { /* already disconnected */ }
  }

  $('start').addEventListener('click', async () => {
    const chosen = [...languagesEl.querySelectorAll('input:checked')].map(el => el.value);
    if (!selectedFile || !chosen.length || !videoId || !confirm(`Thêm cùng một MP3 cho ${chosen.length} ngôn ngữ?`)) return;

    running = true;
    updateStart();
    $('stop').disabled = false;
    resultsEl.replaceChildren();
    resultRows.clear();

    try {
      closePort();
      port = chrome.tabs.connect(tabId, { name: 'audio-transfer' });
      const activePort = port;

      const onMessage = message => {
        if (message.type === 'stage') status(`${message.name}: ${message.stage}`);
        if (message.type === 'result') appendResult(message);
        if (message.type === 'error') {
          status(`Lỗi: ${message.error}`);
          running = false;
          $('stop').disabled = true;
          updateStart();
          activePort.onMessage.removeListener(onMessage);
          closePort();
        }
        if (message.type === 'complete') {
          status(message.results.some(x => x.status === 'failed')
            ? 'Đã dừng sau lỗi. Kiểm tra kết quả và tải lại danh sách trước khi thử tiếp.'
            : 'Đã kết thúc lượt chạy. Kiểm tra các kết quả bên dưới.');
          running = false;
          $('stop').disabled = true;
          updateStart();
          activePort.onMessage.removeListener(onMessage);
          closePort();
          refresh();
        }
      };

      const onDisconnect = () => {
        activePort.onMessage.removeListener(onMessage);
        activePort.onDisconnect.removeListener(onDisconnect);
        if (port === activePort) port = null;
        if (running) status('Mất kết nối với trang Studio. Hãy tải lại và kiểm tra kết quả.');
        running = false;
        $('stop').disabled = true;
        updateStart();
      };

      activePort.onMessage.addListener(onMessage);
      activePort.onDisconnect.addListener(onDisconnect);
      await sendFile(activePort, selectedFile);
      activePort.postMessage({ type: 'run', videoId, languages: chosen });
    } catch (error) {
      status(`Lỗi: ${error.message}`);
      running = false;
      $('stop').disabled = true;
      updateStart();
      closePort();
    }
  });

  refresh();
})();
