(() => {
  let currentPort = null;
  let stopped = false;
  let busy = false;

  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message.type !== 'discover') return;
    StudioDom.discoverLanguages().then(
      languages => reply({ ok: true, videoId: StudioDom.videoIdFromUrl(location.href), languages }),
      error => reply({ ok: false, error: error.message })
    );
    return true;
  });

  chrome.runtime.onConnect.addListener(port => {
    if (port.name !== 'audio-transfer') return;
    if (busy || currentPort) {
      port.postMessage({ type: 'error', error: 'Đang có một lượt chạy khác.' });
      port.disconnect();
      return;
    }

    currentPort = port;
    stopped = false;
    const send = message => { try { port.postMessage(message); } catch { /* panel may be on another tab */ } };
    let chunks = [];
    let expected = 0;
    let fileName = '';
    let file = null;

    // Switching tabs can detach the side panel port. Keep the tab runner alive;
    // a later panel connection can inspect the resulting Studio state.
    port.onDisconnect.addListener(() => { currentPort = null; });

    port.onMessage.addListener(async message => {
      try {
        if (message.type === 'begin') {
          expected = message.size;
          fileName = message.name;
          if (!Number.isSafeInteger(expected) || expected < 1 || expected > 1024 * 1024 * 1024) throw Error('Kích thước MP3 không hợp lệ.');
          chunks.length = 0;
          send({ type: 'ready' });
        } else if (message.type === 'chunk') {
          const binary = atob(message.data);
          const bytes = new Uint8Array(binary.length);
          // PERF: avoid Uint8Array.from callback allocation once per byte.
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          chunks.push(bytes);
          send({ type: 'ack', index: message.index });
        } else if (message.type === 'end') {
          const bytes = AudioTransfer.joinBytes(chunks, expected);
          chunks.length = 0;
          file = new File([bytes], fileName, { type: 'audio/mpeg' });
          send({ type: 'file-ready' });
        } else if (message.type === 'stop') {
          stopped = true;
          send({ type: 'stopping' });
        } else if (message.type === 'run') {
          if (busy || !file) throw Error('Chưa nhận đủ MP3 hoặc tác vụ đang chạy.');
          if (message.videoId !== StudioDom.videoIdFromUrl(location.href)) throw Error('Video đã thay đổi. Hãy tải lại danh sách.');

          busy = true;
          const selected = [...new Set(message.languages)];
          // Preserve original pre-run validation/discovery behavior.
          const available = (await StudioDom.discoverLanguages(() => stopped)).map(x => x.name);
          const targets = AudioRunner.selectTargets(available, [], selected);
          const targetSet = new Set(targets);
          for (const name of selected) {
            if (!targetSet.has(name)) send({ type: 'result', name, status: 'skipped' });
          }

          const results = await AudioRunner.runSequential(
            targets,
            name => StudioDom.addAudioTrack(name, file, () => stopped, stage => send({ type: 'stage', name, stage })),
            () => stopped,
            item => {
              send({ type: 'result', name: item.code, status: item.status, error: item.error });
              if (item.status !== 'running') {
                chrome.storage.local.set({
                  [`progress:${message.videoId}:${item.code}`]: {
                    status: item.status,
                    error: item.error || '',
                    at: Date.now()
                  }
                });
              }
            }
          );

          busy = false;
          file = null;
          targetSet.clear();
          send({ type: 'complete', results });
        }
      } catch (error) {
        busy = false;
        chunks.length = 0;
        file = null;
        send({ type: 'error', error: error.message });
      }
    });
  });
})();
