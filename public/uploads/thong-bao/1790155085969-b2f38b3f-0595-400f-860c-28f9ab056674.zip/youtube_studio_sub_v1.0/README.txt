Studio Audio Tracks 0.1.1 - performance fix

Main behavior is intentionally unchanged:
- Discover languages through YouTube Studio's Add language menu.
- Select one MP3 in the side panel.
- Process selected languages sequentially.
- For each language: choose language -> Add audio -> attach MP3 -> Publish -> Update -> continue.
- Stop/error/success semantics remain the same.

Performance-only changes:
- Removed innerText from hot DOM scans.
- Reduced forced layout visibility checks to small candidate sets.
- Discover scans translation rows once and reuses an index.
- Removed duplicate languageMenuItems scan inside a single poll iteration.
- Reduced repeated whole-document work in Add-audio lookup while retaining fallbacks.
- Reduced per-byte allocation during MP3 transfer.
- Batched side-panel language rendering with DocumentFragment.
- Cached result rows instead of querying the panel DOM for every result.
- Cleaned up completed/error ports and temporary listeners.

No batching, page reload, direct-row workflow rewrite, parallel upload, or save-wait behavior was added.
