(function(root) {
  function selectTargets(available, existing, selected) {
    const allowed = new Set(available);
    const done = new Set(existing);
    return selected.filter(code => allowed.has(code) && !done.has(code));
  }
  async function runSequential(targets, action, isStopped, report = () => {}) {
    const results = [];
    for (const code of targets) {
      if (isStopped()) break;
      report({ code, status: 'running' });
      try {
        await action(code);
        results.push({ code, status: 'success' });
      } catch (error) {
        results.push({ code, status: 'failed', error: String(error.message || error) });
      }
      report(results.at(-1));
      if (results.at(-1).status === 'failed') break;
    }
    return results;
  }
  const api = { selectTargets, runSequential };
  if (typeof module !== 'undefined') module.exports = api;
  else root.AudioRunner = api;
})(globalThis);