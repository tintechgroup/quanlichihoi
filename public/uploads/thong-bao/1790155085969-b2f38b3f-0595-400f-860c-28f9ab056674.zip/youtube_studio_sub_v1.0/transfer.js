(function(root) {
  function splitBytes(bytes, size = 256 * 1024) {
    const chunks = [];
    for (let i = 0; i < bytes.length; i += size) chunks.push(bytes.slice(i, i + size));
    return chunks;
  }
  function joinBytes(chunks, expected) {
    const size = chunks.reduce((n, c) => n + c.length, 0);
    if (size !== expected) throw Error('Incomplete file transfer');
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    return bytes;
  }
  const api = { splitBytes, joinBytes };
  if (typeof module !== 'undefined') module.exports = api;
  else root.AudioTransfer = api;
})(globalThis);