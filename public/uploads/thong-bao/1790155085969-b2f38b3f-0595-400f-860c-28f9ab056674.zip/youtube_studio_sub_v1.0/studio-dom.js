(function(root) {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const CONTROL_SELECTOR = 'button,[role="button"],[role="menuitem"],ytcp-button,ytcp-text-menu-item,ytcp-ve,ytcp-dropdown-trigger';
  const ROW_SELECTOR = 'ytcp-video-translation-row,.ytgn-video-translation-row,[role="row"],tr';
  const MENU_SELECTOR = 'ytcp-text-menu';
  let cachedAddLanguageControl = null;

  const normalizeLanguage = value => String(value || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase();
  const languageAliases = new Map([
    ['sherdukpen', 'sdp'],
    ['sdp', 'sdp']
  ]);

  function languageKey(value) {
    const normalized = normalizeLanguage(value);
    return languageAliases.get(normalized) || normalized;
  }

  function isAudioControlLabel(value) {
    const text = normalizeLanguage(value);
    return /audio|âm thanh|bản âm thanh|tệp âm thanh|upload audio|tải (lên|tệp)/i.test(text);
  }

  function structurallyVisible(el) {
    if (!el || !el.isConnected || el.hidden || el.getAttribute?.('aria-hidden') === 'true') return false;
    return !el.closest?.('[hidden],[aria-hidden="true"]');
  }

  // PERF: layout-sensitive visibility is only used on final/small candidate sets.
  function visible(el) {
    if (!structurallyVisible(el)) return false;
    return !!(el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
  }

  // PERF: textContent avoids the layout flush that innerText can trigger.
  function label(el) {
    return ((el?.getAttribute?.('aria-label')) || el?.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function findUploadInput(rootNode = document) {
    const inputs = rootNode.querySelectorAll('input[type="file"]');
    for (const input of inputs) {
      if (input.disabled || input.hasAttribute('disabled')) continue;
      if (/audio|mp3/i.test(input.getAttribute?.('accept') || '') || /audio|âm thanh|mp3/i.test(label(input.parentElement || input))) return input;
    }
    return null;
  }

  function videoIdFromUrl(url) {
    try { return new URL(url).pathname.match(/^\/video\/([A-Za-z0-9_-]{11})(?:\/|$)/)?.[1] || null; }
    catch { return null; }
  }

  // PERF: do not run visibility/layout checks on every control in the page.
  function controls(rootNode = document) {
    return [...rootNode.querySelectorAll(CONTROL_SELECTOR)];
  }

  function matching(rootNode, patterns, exact = false) {
    const prepared = patterns.map(pattern => pattern instanceof RegExp ? pattern : normalizeLanguage(pattern));
    const found = [];
    for (const el of controls(rootNode)) {
      if (!structurallyVisible(el)) continue;
      const value = normalizeLanguage(label(el));
      const matches = prepared.some(pattern => pattern instanceof RegExp ? pattern.test(value) : exact ? value === pattern : value.includes(pattern));
      if (matches && visible(el)) found.push(el);
    }
    return found;
  }

  function uniqueControl(rootNode, patterns, purpose, exact = false) {
    const found = matching(rootNode, patterns, exact);
    // Same leaf-control behavior as the old matching(el, ...) call, without
    // repeatedly querying descendants for every candidate.
    const leaves = found.filter(el => !found.some(other => other !== el && el.contains?.(other)));
    if (leaves.length !== 1) throw Error(`Không xác định được nút ${purpose} (${leaves.length} kết quả).`);
    return leaves[0];
  }

  function addLanguageControl() {
    if (cachedAddLanguageControl?.isConnected &&
        /add language|thêm ngôn ngữ/i.test(label(cachedAddLanguageControl)) &&
        visible(cachedAddLanguageControl)) {
      return cachedAddLanguageControl;
    }
    cachedAddLanguageControl = uniqueControl(document, [/add language|thêm ngôn ngữ/i], 'Thêm ngôn ngữ');
    return cachedAddLanguageControl;
  }

  async function waitFor(fn, purpose, timeout = 12000, stopped = () => false) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      if (stopped()) throw Error('Đã dừng theo yêu cầu.');
      const result = fn();
      if (result) return result;
      await sleep(250);
    }
    throw Error(`Hết thời gian chờ: ${purpose}.`);
  }

  function languageMenuItems(rootNode = document, before = new Set()) {
    const result = [];
    const menus = rootNode.querySelectorAll(MENU_SELECTOR);
    for (const menu of menus) {
      if (before.has(menu) || !visible(menu)) continue;
      const textNodes = menu.querySelectorAll('.item-text.main-text');
      for (const el of textNodes) {
        if (!structurallyVisible(el)) continue;
        const name = el.textContent?.replace(/\s+/g, ' ').trim() || '';
        if (name) result.push({ el, name });
      }
    }
    return result;
  }

  function clickLanguageItem(textNode) {
    const item = textNode.closest?.('[role="menuitem"],ytcp-menu-item,ytcp-text-menu-item') || textNode;
    item.click();
  }

  function buildLanguageRowIndex(rootNode = document) {
    const exact = new Map();
    const records = [];
    const rows = rootNode.querySelectorAll(ROW_SELECTOR);
    for (const row of rows) {
      if (!structurallyVisible(row)) continue;
      const languageNode = row.querySelector?.('.language-text') || row;
      const key = languageKey(label(languageNode));
      if (!key) continue;
      const record = { key, row };
      records.push(record);
      if (!exact.has(key)) exact.set(key, row);
    }
    return { exact, records };
  }

  function rowFromIndex(name, index) {
    const key = languageKey(name);
    const exact = index.exact.get(key);
    if (exact) return exact;
    // Preserve the old includes() fallback for rows whose label contains
    // extra text in a Studio UI variant.
    return index.records.find(record => record.key.includes(key))?.row || null;
  }

  function languageRow(name, rootNode = document, rowIndex = null) {
    const index = rowIndex || buildLanguageRowIndex(rootNode);
    return rowFromIndex(name, index);
  }

  function hasExistingAudioTrack(name, rootNode = document, rowIndex = null) {
    const row = languageRow(name, rootNode, rowIndex);
    if (!row) return false;
    const status = row.querySelector?.('#language-details-status-label-audio,.language-details-status-label');
    const text = normalizeLanguage(status?.textContent || '');
    if (text && !/add|thêm|upload|tải lên/i.test(text)) return true;
    return !row.querySelector?.('#language-details-text-button-audio button[aria-label="Thêm"]');
  }

  function audioAddControl(row) {
    if (!row) return null;
    const found = [];
    for (const el of controls(row)) {
      if (!structurallyVisible(el)) continue;
      if (/^(thêm|add|tải lên|upload)$/i.test(label(el)) && visible(el)) found.push(el);
    }
    const candidates = found.filter(el => !found.some(other => el !== other && el.contains?.(other)));
    let audioCell = null;
    for (const cell of row.querySelectorAll('ytcp-video-translation-cell,[role="cell"],td')) {
      if (/audio|âm thanh/i.test(label(cell))) { audioCell = cell; break; }
    }
    const scoped = audioCell ? candidates.filter(el => audioCell.contains(el)) : candidates;
    return scoped.length === 1 ? scoped[0] : null;
  }

  function findAudioAddAction(rootNode = document, name, before = new Set()) {
    const audioButton = rootNode.querySelector?.('#language-details-text-button-audio button[aria-label="Thêm"]');
    if (audioButton && audioButton.getAttribute?.('aria-disabled') !== 'true' && !audioButton.disabled && visible(audioButton)) return audioButton;

    // Keep the old "fresh button" preference, but only perform expensive
    // visibility checks on new/enabled candidates rather than every Add button.
    const all = [...rootNode.querySelectorAll('button[aria-label="Thêm"]')]
      .filter(button => button.disabled !== true && button.getAttribute?.('aria-disabled') !== 'true');
    const fresh = all.filter(button => !before.has(button) && structurallyVisible(button));
    const visibleFresh = fresh.filter(visible);
    if (visibleFresh.length === 1) return visibleFresh[0];

    const row = languageRow(name, rootNode);
    if (row) {
      const inRow = audioAddControl(row);
      if (inRow) return inRow;
    }

    const dialogs = rootNode.querySelectorAll('tp-yt-paper-dialog[role="dialog"],[role="dialog"]');
    const inDialogs = [];
    for (const dialog of dialogs) {
      if (!visible(dialog)) continue;
      for (const button of dialog.querySelectorAll('button[aria-label="Thêm"]')) {
        if (visible(button)) inDialogs.push(button);
      }
    }
    if (inDialogs.length === 1) return inDialogs[0];

    // Rare fallback: preserve previous behavior of returning the last visible
    // enabled Add button when Studio's DOM shape cannot be scoped further.
    for (let i = all.length - 1; i >= 0; i--) {
      if (visible(all[i])) return all[i];
    }
    return null;
  }

  function activateButton(button) {
    if (!button) throw Error('Không tìm thấy nút cần bấm.');
    if (typeof MouseEvent !== 'undefined' && button.dispatchEvent) {
      button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, composed: true, view: window }));
      button.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, composed: true, view: window }));
    }
    button.click();
  }

  function uploadDialog(rootNode = document) {
    const dialogs = rootNode.querySelectorAll('tp-yt-paper-dialog[aria-labelledby="crowdsourcing-audio-upload-dialog-title"]');
    for (const dialog of dialogs) if (visible(dialog)) return dialog;
    return null;
  }

  function attachFile(input, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function chooseFileWithoutPicker(dialog, file, stopped = () => false) {
    const button = dialog.querySelector('#upload-button button[aria-label="Chọn tệp"]');
    if (!button) throw Error('Không tìm thấy nút Chọn tệp trong hộp thoại âm thanh.');
    const directInput = findUploadInput(dialog);
    if (directInput) { attachFile(directInput, file); return; }
    if (stopped()) throw Error('Đã dừng theo yêu cầu.');

    let handler;
    let timer;
    const inputClick = new Promise((resolve, reject) => {
      timer = setTimeout(() => reject(Error('Studio không mở input tệp sau khi bấm Chọn tệp.')), 5000);
      handler = event => {
        const input = event.composedPath?.().find(node => node?.matches?.('input[type="file"]'));
        if (!input) return;
        event.preventDefault();
        clearTimeout(timer);
        timer = null;
        resolve(input);
      };
      document.addEventListener('click', handler, true);
    });
    try {
      button.click();
      const input = await inputClick;
      attachFile(input, file);
    } finally {
      if (timer) clearTimeout(timer);
      document.removeEventListener('click', handler, true);
    }
  }

  async function discoverLanguages(stopped = () => false) {
    if (!videoIdFromUrl(location.href)) throw Error('Mở trang Ngôn ngữ của một video trong YouTube Studio.');
    const add = addLanguageControl();
    const before = new Set([...document.querySelectorAll(MENU_SELECTOR)].filter(visible));
    add.click();
    try {
      const items = await waitFor(() => {
        const found = languageMenuItems(document, before);
        return found.length ? found : null;
      }, 'danh sách ngôn ngữ', 8000, stopped);
      const names = [...new Set(items.map(x => x.name))];

      // PERF: scan translation rows once. The old implementation rescanned the
      // whole table once for every language in the Add-language menu.
      const rowIndex = buildLanguageRowIndex(document);
      return names.map(name => ({ name, existing: hasExistingAudioTrack(name, document, rowIndex) }));
    } finally {
      before.clear();
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      const menus = document.querySelectorAll('[role="menu"],ytcp-text-menu');
      let openMenu = false;
      for (const menu of menus) {
        if (visible(menu)) { openMenu = true; break; }
      }
      if (openMenu) document.body.click();
    }
  }

  async function addAudioTrack(name, file, stopped, report) {
    const step = message => { if (stopped()) throw Error('Đã dừng theo yêu cầu.'); report(message); };
    step('Chọn ngôn ngữ');

    // PERF: structural snapshot avoids forcing layout on every Add button.
    const beforeAdd = new Set([...document.querySelectorAll('button[aria-label="Thêm"]')].filter(structurallyVisible));
    const before = new Set([...document.querySelectorAll(MENU_SELECTOR)].filter(visible));
    const targetName = normalizeLanguage(name);

    addLanguageControl().click();
    const option = await waitFor(() => {
      const items = languageMenuItems(document, before);
      const found = items.filter(x => normalizeLanguage(x.name) === targetName);
      return found.length ? found : null;
    }, `ngôn ngữ ${name}`, 8000, stopped);
    if (option.length !== 1) throw Error(`Ngôn ngữ ${name} không rõ ràng trong danh sách.`);
    clickLanguageItem(option[0].el);

    step('Mở vùng bản âm thanh');
    const addAudio = await waitFor(() => findAudioAddAction(document, name, beforeAdd), `nút Thêm âm thanh của ${name}`, 15000, stopped);
    activateButton(addAudio);

    step('Chọn MP3 trong hộp thoại');
    const dialog = await waitFor(() => uploadDialog(document), 'hộp thoại Thêm bản âm thanh', 10000, stopped);
    await chooseFileWithoutPicker(dialog, file, stopped);

    step('Đợi tải tệp');
    const fileName = normalizeLanguage(file.name);
    await waitFor(() => normalizeLanguage(dialog.querySelector('.file-name')?.textContent) === fileName, 'tên MP3 trong hộp thoại', 120000, stopped);
    const publish = await waitFor(() => {
      const button = dialog.querySelector('#publish-button button[aria-label="Xuất bản"]');
      return button && !button.disabled && button.getAttribute('aria-disabled') !== 'true' ? button : null;
    }, 'nút Xuất bản', 120000, stopped);
    publish.click();

    step('Cập nhật video');
    const update = await waitFor(() => {
      const buttons = document.querySelectorAll('button[aria-label="Cập nhật"]');
      for (const button of buttons) {
        if (button.disabled === true || button.getAttribute?.('aria-disabled') === 'true') continue;
        if (visible(button)) return button;
      }
      return null;
    }, 'nút Cập nhật', 30000, stopped);
    activateButton(update);

    // Preserve original behavior: submit Update and immediately prepare the
    // next language without waiting for Studio's asynchronous processing state.
    step('Đã nhấn Cập nhật; chuyển sang ngôn ngữ tiếp theo');

    beforeAdd.clear();
    before.clear();
  }

  const api = {
    videoIdFromUrl,
    normalizeLanguage,
    languageKey,
    isAudioControlLabel,
    findUploadInput,
    languageMenuItems,
    clickLanguageItem,
    languageRow,
    hasExistingAudioTrack,
    audioAddControl,
    findAudioAddAction,
    activateButton,
    chooseFileWithoutPicker,
    discoverLanguages,
    addAudioTrack,
    waitFor
  };
  if (typeof module !== 'undefined') module.exports = api;
  else root.StudioDom = api;
})(globalThis);
