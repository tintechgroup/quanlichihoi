import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,

  {
    rules: {
      // Các trang hiện tại dùng useEffect để tải dữ liệu rồi setState.
      // Cho phép tạm thời, tránh ESLint chặn deploy.
      "react-hooks/set-state-in-effect": "warn",

      // Các trang hoạt động dùng Date.now() để kiểm tra hạn đăng ký.
      "react-hooks/purity": "warn",

      // Cần thay any bằng interface cụ thể sau, nhưng không chặn build.
      "@typescript-eslint/no-explicit-any": "warn",

      // Không chặn build khi biến cục bộ đang có tên module.
      "@next/next/no-assign-module-variable": "warn",
    },
  },

  globalIgnores([
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
    "node_modules/**",
  ]),
]);

export default eslintConfig;